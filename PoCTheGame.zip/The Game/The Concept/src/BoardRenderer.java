import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JComponent;


public class BoardRenderer extends JComponent{
	public void paint (Graphics g, int x, int y, int i, int j, Board board){
		
		if(board.getGrid()[i][j].isSolid()){
			g.setColor(Color.YELLOW);
		}else if(board.getGrid()[i][j].containsEnemy()){
			g.setColor(Color.RED);
		}else if(board.getGrid()[i][j].containsHero()){
			g.setColor(Color.GREEN);
		}else if(board.getGrid()[i][j].isObjective()){
			g.setColor(Color.BLACK);
		}else {
			g.setColor(Color.BLUE);
		}
		
		g.fillRect(x, y, 25, 25);
	}
}
