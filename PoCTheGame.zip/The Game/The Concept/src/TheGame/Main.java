package TheGame;

import org.lwjgl.LWJGLException;
import org.lwjgl.opengl.*;

import static org.lwjgl.opengl.GL11.*;


public class Main {
	
	public static final int WIDTH = 600, HEIGHT = 400;
	
	public Main(){
		Display.setTitle("Proof Of Concept: The Game");
		try {
			Display.setDisplayMode(new DisplayMode(WIDTH, HEIGHT));
			Display.create();
		} catch (LWJGLException e) { 
			e.printStackTrace();
		}
		
		//Graphics for rendering the board
		glMatrixMode(GL_PROJECTION);	//Recognize board
		glLoadIdentity();				//Load Display
		glOrtho(0, 600, 400, 0, 1, -1);			//Sets up camera for screen to see in parameters(far left, far right, top, bottom, 3d(zNear), 3d(zFar))
		glMatrixMode(GL_MODELVIEW);		//Sets the screen view
		
		while(!Display.isCloseRequested()){
			glBegin(GL_LINES);
			//Creates a line in the screen if not, becauase you have a mac LOLZ
			glVertex2f(10,10);
			glVertex2f(100,100);
			glEnd();
			
			glBegin(GL_QUADS);
			glVertex2f(100, 100);
			glVertex2f(150, 100);
			glVertex2f(150, 150);
			glVertex2f(100, 150);
			glEnd();
			
			
			
			//Sets the screen to update in the loop to render the black screen and fps (frame per second)
			Display.update();
			Display.sync(60);
		}
		
		//Ends the Game
		Display.destroy();
	}
	
	public static void main(String [] args){
		new Main();
	}
}
