package TheGame;
	
	
	public class Board {
		
		private Tile t;
		
		public Board() {
			t = new t[]
		}
	}

