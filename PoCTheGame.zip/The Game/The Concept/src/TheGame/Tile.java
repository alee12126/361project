package TheGame;
	
	public class Tile {
		private boolean isSolid;
		private boolean containsEnemy;
		private boolean containsHero;
		private boolean isObjective;
	
		public Tile(){
			isSolid = false;
			containsEnemy = false;
			containsHero = false;
			isObjective = false;
		}
	
		public boolean isSolid() {
			return isSolid;
		}
		public void setIsSolid(boolean isSolid) {
			this.isSolid = isSolid;
		}
		public boolean containsEnemy() {
			return containsEnemy;
		}
		public void setContainsEnemy(boolean containsEnemy) {
			this.containsEnemy = containsEnemy;
		}
		public boolean containsHero() {
			return containsHero;
		}
		public void setContainsHero(boolean containsHero) {
			this.containsHero = containsHero;
		}
		public boolean isObjective() {
			return isObjective;
		}
		public void setIsObjective(boolean isObjective) {
			this.isObjective = isObjective;
		}
	}
