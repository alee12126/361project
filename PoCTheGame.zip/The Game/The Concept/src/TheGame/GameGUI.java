package TheGame;
/*

Davyen Nelson, James Reynolds, Andrew Lee

The Game
Group 2 Project
03/15/15
CSCE 361

*/


//import Board;
//import BoardRenderer;

import javax.swing.*;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class GameGUI{
	
	
//	private JFrame mainFrame;
//	private Board board;
//	private Graphics g;
//	private BoardRenderer component = new BoardRenderer();
////	private Game game;
//
//	public GameGUI(){
////		Game owner
//		map(board);
////		game = owner;
//	}
//
//	public void map(Board board){
//		//Set the main frame holder for the label and button
//		mainFrame = new JFrame("Proof of Concept: The Game");
//		mainFrame.setSize(board.getGrid().length*25 , board.getGrid()[0].length*25);
//		mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//		mainFrame.setVisible(true);
//		mainFrame.setLocationRelativeTo(null);
//		mainFrame.getContentPane().add(component);
//
//	}
//	
//	public void update(){
//		int drawx = 0;
//		int drawy = 0;
//		
//		for(int i = 0; i < board.getGrid().length; i++){
//			for(int j = 0; j < board.getGrid()[0].length; j++){
//				component.paint(g, drawx, drawy, i, j, board);
//				drawx += 25;
//				drawy += 25;
//			}
////			game.setBoard(board);
//		}
//	}
//
////Getter and Setters for variables
//
//	public JFrame getMainFrame() {
//		return mainFrame;
//	}
//
//	public void setMainFrame(JFrame mainFrame) {
//		this.mainFrame = mainFrame;
//	}
//
//	@Override
//	public void keyTyped(KeyEvent e) {
//		// TODO Auto-generated method stub
//		
//	}
//
//	@Override
//	public void keyPressed(KeyEvent e) {
//		// TODO Auto-generated method stub
//		
//	}
//
//	@Override
//	public void keyReleased(KeyEvent e) {
//		// TODO Auto-generated method stub
//		
//	}
//	
//	public static void main(String [] args){
//		
//
//		Board board = new Board();
//		GameGUI demo = new GameGUI();
//		demo.map(board);
//
//	}

	
/*
 * 
 * 
 * 					New Code located below
 * 
 * 
 * 
 * 
 * 	
 */
	
	
	
	
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}