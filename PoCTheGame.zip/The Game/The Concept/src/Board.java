import TheGame.Tile;


public class Board {
	private Tile[][] grid = new Tile[8][8];
	private Tile[][] dest = new Tile[8][8];
	private int objectiveCol;
	private int objectiveRow;
	private int heroCol;
	private int heroRow;
	
	public Tile[][] getGrid() {
		this.grid = dest;
		return grid;
	}
	
	Board(){
		grid[0][0].setIsSolid(true);
		grid[0][0].setContainsEnemy(false);
		grid[0][0].setContainsHero(false);
		grid[0][0].setIsObjective(false);
		
		grid[0][1].setIsSolid(true);
		grid[0][1].setContainsEnemy(false);
		grid[0][1].setContainsHero(false);
		grid[0][1].setIsObjective(false);
		
		grid[0][2].setIsSolid(true);
		grid[0][2].setContainsEnemy(false);
		grid[0][2].setContainsHero(false);
		grid[0][2].setIsObjective(false);
		
		grid[0][3].setIsSolid(false);
		grid[0][3].setContainsEnemy(false);
		grid[0][3].setContainsHero(false);
		grid[0][3].setIsObjective(true);
		
		grid[0][4].setIsSolid(false);
		grid[0][4].setContainsEnemy(false);
		grid[0][4].setContainsHero(false);
		grid[0][4].setIsObjective(false);
		
		grid[0][5].setIsSolid(false);
		grid[0][5].setContainsEnemy(false);
		grid[0][5].setContainsHero(false);
		grid[0][5].setIsObjective(false);

		grid[0][6].setIsSolid(true);
		grid[0][6].setContainsEnemy(false);
		grid[0][6].setContainsHero(false);
		grid[0][6].setIsObjective(false);
		
		grid[0][7].setIsSolid(true);
		grid[0][7].setContainsEnemy(false);
		grid[0][7].setContainsHero(false);
		grid[0][7].setIsObjective(false);
		
		//end column 0
		
		grid[1][0].setIsSolid(false);
		grid[1][0].setContainsEnemy(false);
		grid[1][0].setContainsHero(false);
		grid[1][0].setIsObjective(false);
		
		grid[1][1].setIsSolid(false);
		grid[1][1].setContainsEnemy(true);
		grid[1][1].setContainsHero(false);
		grid[1][1].setIsObjective(false);
		
		grid[1][2].setIsSolid(false);
		grid[1][2].setContainsEnemy(false);
		grid[1][2].setContainsHero(false);
		grid[1][2].setIsObjective(false);
		
		grid[1][3].setIsSolid(true);
		grid[1][3].setContainsEnemy(false);
		grid[1][3].setContainsHero(false);
		grid[1][3].setIsObjective(false);
		
		grid[1][4].setIsSolid(false);
		grid[1][4].setContainsEnemy(false);
		grid[1][4].setContainsHero(false);
		grid[1][4].setIsObjective(false);
		
		grid[1][5].setIsSolid(false);
		grid[1][5].setContainsEnemy(false);
		grid[1][5].setContainsHero(false);
		grid[1][5].setIsObjective(false);
		
		grid[1][6].setIsSolid(false);
		grid[1][6].setContainsEnemy(true);
		grid[1][6].setContainsHero(false);
		grid[1][6].setIsObjective(false);
		
		grid[1][7].setIsSolid(true);
		grid[1][7].setContainsEnemy(false);
		grid[1][7].setContainsHero(false);
		grid[1][7].setIsObjective(false);
		
		//end column 1
		
		grid[2][0].setIsSolid(false);
		grid[2][0].setContainsEnemy(false);
		grid[2][0].setContainsHero(false);
		grid[2][0].setIsObjective(false);
	
		grid[2][1].setIsSolid(true);
		grid[2][1].setContainsEnemy(false);
		grid[2][1].setContainsHero(false);
		grid[2][1].setIsObjective(false);
		
		grid[2][2].setIsSolid(false);
		grid[2][2].setContainsEnemy(false);
		grid[2][2].setContainsHero(false);
		grid[2][2].setIsObjective(false);
		
		grid[2][3].setIsSolid(false);
		grid[2][3].setContainsEnemy(true);
		grid[2][3].setContainsHero(false);
		grid[2][3].setIsObjective(false);
		
		grid[2][4].setIsSolid(false);
		grid[2][4].setContainsEnemy(false);
		grid[2][4].setContainsHero(false);
		grid[2][4].setIsObjective(false);
		
		grid[2][5].setIsSolid(true);
		grid[2][5].setContainsEnemy(false);
		grid[2][5].setContainsHero(false);
		grid[2][5].setIsObjective(false);
		
		grid[2][6].setIsSolid(false);
		grid[2][6].setContainsEnemy(false);
		grid[2][6].setContainsHero(false);
		grid[2][6].setIsObjective(false);
		
		grid[2][7].setIsSolid(true);
		grid[2][7].setContainsEnemy(false);
		grid[2][7].setContainsHero(false);
		grid[2][7].setIsObjective(false);
		
		//end column 2
		
		grid[3][0].setIsSolid(false);
		grid[3][0].setContainsEnemy(true);
		grid[3][0].setContainsHero(false);
		grid[3][0].setIsObjective(false);
		
		grid[3][1].setIsSolid(true);
		grid[3][1].setContainsEnemy(false);
		grid[3][1].setContainsHero(false);
		grid[3][1].setIsObjective(false);
		
		grid[3][2].setIsSolid(true);
		grid[3][2].setContainsEnemy(false);
		grid[3][2].setContainsHero(false);
		grid[3][2].setIsObjective(false);
		
		grid[3][3].setIsSolid(true);
		grid[3][3].setContainsEnemy(false);
		grid[3][3].setContainsHero(false);
		grid[3][3].setIsObjective(false);
		
		grid[3][4].setIsSolid(true);
		grid[3][4].setContainsEnemy(false);
		grid[3][4].setContainsHero(false);
		grid[3][4].setIsObjective(false);
		
		grid[3][5].setIsSolid(true);
		grid[3][5].setContainsEnemy(false);
		grid[3][5].setContainsHero(false);
		grid[3][5].setIsObjective(false);
		
		grid[3][6].setIsSolid(false);
		grid[3][6].setContainsEnemy(true);
		grid[3][6].setContainsHero(false);
		grid[3][6].setIsObjective(false);
		
		grid[3][7].setIsSolid(false);
		grid[3][7].setContainsEnemy(false);
		grid[3][7].setContainsHero(false);
		grid[3][7].setIsObjective(false);
		
		//end column 3
		
		grid[4][0].setIsSolid(false);
		grid[4][0].setContainsEnemy(false);
		grid[4][0].setContainsHero(false);
		grid[4][0].setIsObjective(false);
		
		grid[4][1].setIsSolid(false);
		grid[4][1].setContainsEnemy(false);
		grid[4][1].setContainsHero(false);
		grid[4][1].setIsObjective(false);
		
		grid[4][2].setIsSolid(false);
		grid[4][2].setContainsEnemy(false);
		grid[4][2].setContainsHero(false);
		grid[4][2].setIsObjective(false);
		
		grid[4][3].setIsSolid(false);
		grid[4][3].setContainsEnemy(false);
		grid[4][3].setContainsHero(false);
		grid[4][3].setIsObjective(false);
		
		grid[4][4].setIsSolid(false);
		grid[4][4].setContainsEnemy(false);
		grid[4][4].setContainsHero(false);
		grid[4][4].setIsObjective(false);
		
		grid[4][5].setIsSolid(true);
		grid[4][5].setContainsEnemy(false);
		grid[4][5].setContainsHero(false);
		grid[4][5].setIsObjective(false);
		
		grid[4][6].setIsSolid(true);
		grid[4][6].setContainsEnemy(false);
		grid[4][6].setContainsHero(false);
		grid[4][6].setIsObjective(false);
		
		grid[4][7].setIsSolid(false);
		grid[4][7].setContainsEnemy(false);
		grid[4][7].setContainsHero(false);
		grid[4][7].setIsObjective(false);
		
		//end column 4
		
		grid[5][0].setIsSolid(false);
		grid[5][0].setContainsEnemy(true);
		grid[5][0].setContainsHero(false);
		grid[5][0].setIsObjective(false);
		
		grid[5][1].setIsSolid(true);
		grid[5][1].setContainsEnemy(false);
		grid[5][1].setContainsHero(false);
		grid[5][1].setIsObjective(false);
		
		grid[5][2].setIsSolid(false);
		grid[5][2].setContainsEnemy(true);
		grid[5][2].setContainsHero(false);
		grid[5][2].setIsObjective(false);
		
		grid[5][3].setIsSolid(true);
		grid[5][3].setContainsEnemy(false);
		grid[5][3].setContainsHero(false);
		grid[5][3].setIsObjective(false);
		
		grid[5][4].setIsSolid(false);
		grid[5][4].setContainsEnemy(false);
		grid[5][4].setContainsHero(false);
		grid[5][4].setIsObjective(false);
		
		grid[5][5].setIsSolid(false);
		grid[5][5].setContainsEnemy(true);
		grid[5][5].setContainsHero(false);
		grid[5][5].setIsObjective(false);
		
		grid[5][6].setIsSolid(false);
		grid[5][6].setContainsEnemy(false);
		grid[5][6].setContainsHero(false);
		grid[5][6].setIsObjective(false);
		
		grid[5][7].setIsSolid(false);
		grid[5][7].setContainsEnemy(false);
		grid[5][7].setContainsHero(false);
		grid[5][7].setIsObjective(false);
		
		//end column 5
		
		grid[6][0].setIsSolid(true);
		grid[6][0].setContainsEnemy(false);
		grid[6][0].setContainsHero(false);
		grid[6][0].setIsObjective(false);
		
		grid[6][1].setIsSolid(true);
		grid[6][1].setContainsEnemy(false);
		grid[6][1].setContainsHero(false);
		grid[6][1].setIsObjective(false);
		
		grid[6][2].setIsSolid(false);
		grid[6][2].setContainsEnemy(false);
		grid[6][2].setContainsHero(false);
		grid[6][2].setIsObjective(false);
		
		grid[6][3].setIsSolid(true);
		grid[6][3].setContainsEnemy(false);
		grid[6][3].setContainsHero(false);
		grid[6][3].setIsObjective(false);
		
		grid[6][4].setIsSolid(true);
		grid[6][4].setContainsEnemy(false);
		grid[6][4].setContainsHero(false);
		grid[6][4].setIsObjective(false);
		
		grid[6][5].setIsSolid(true);
		grid[6][5].setContainsEnemy(false);
		grid[6][5].setContainsHero(false);
		grid[6][5].setIsObjective(false);

		grid[6][6].setIsSolid(true);
		grid[6][6].setContainsEnemy(false);
		grid[6][6].setContainsHero(false);
		grid[6][6].setIsObjective(false);
		
		grid[6][7].setIsSolid(true);
		grid[6][7].setContainsEnemy(false);
		grid[6][7].setContainsHero(false);
		grid[6][7].setIsObjective(false);
		
		//end column 6
		
		grid[7][0].setIsSolid(false);
		grid[7][0].setContainsEnemy(false);
		grid[7][0].setContainsHero(false);
		grid[7][0].setIsObjective(false);
		
		grid[7][1].setIsSolid(false);
		grid[7][1].setContainsEnemy(true);
		grid[7][1].setContainsHero(false);
		grid[7][1].setIsObjective(false);
		
		grid[7][2].setIsSolid(false);
		grid[7][2].setContainsEnemy(false);
		grid[7][2].setContainsHero(false);
		grid[7][2].setIsObjective(false);
		
		grid[7][3].setIsSolid(false);
		grid[7][3].setContainsEnemy(false);
		grid[7][3].setContainsHero(false);
		grid[7][3].setIsObjective(false);
		
		grid[7][4].setIsSolid(false);
		grid[7][4].setContainsEnemy(false);
		grid[7][4].setContainsHero(false);
		grid[7][4].setIsObjective(false);
		
		grid[7][5].setIsSolid(false);
		grid[7][5].setContainsEnemy(false);
		grid[7][5].setContainsHero(false);
		grid[7][5].setIsObjective(false);
		
		grid[7][6].setIsSolid(false);
		grid[7][6].setContainsEnemy(false);
		grid[7][6].setContainsHero(false);
		grid[7][6].setIsObjective(false);
		
		grid[7][7].setIsSolid(false);
		grid[7][7].setContainsEnemy(false);
		grid[7][7].setContainsHero(true);
		grid[7][7].setIsObjective(false);
		
		//end of column 7
	}
	
	void moveUp(Tile dest){
		if(!dest.containsEnemy() && !dest.isSolid()){
		grid[getHeroCol()][getHeroRow()].setContainsHero(false);
		setHeroRow(getHeroRow() - 1);
		grid[getHeroCol()][getHeroRow()].setContainsHero(true);
		}
	}
	
	void moveLeft(Tile dest){
		if(!dest.containsEnemy() && !dest.isSolid()){
		grid[getHeroCol()][getHeroRow()].setContainsHero(false);
		setHeroCol(getHeroCol() - 1);
		grid[getHeroCol()][getHeroRow()].setContainsHero(true);
		}
	}

	void moveDown(Tile dest){
		if(!dest.containsEnemy() && !dest.isSolid()){
		grid[getHeroCol()][getHeroRow()].setContainsHero(false);
		setHeroRow(getHeroRow() + 1);
		grid[getHeroCol()][getHeroRow()].setContainsHero(true);
		}
	}

	void moveRight(Tile dest){
		if(!dest.containsEnemy() && !dest.isSolid()){
		grid[getHeroCol()][getHeroRow()].setContainsHero(false);
		setHeroCol(getHeroCol() + 1);
		grid[getHeroCol()][getHeroRow()].setContainsHero(true);
		}
	}

	void AttackUp(){
		grid[getHeroCol()][getHeroRow()+1].setContainsEnemy(false);
	}
	
	void AttackLeft(){
		grid[getHeroCol()-1][getHeroRow()].setContainsEnemy(false);
	}
	
	void AttackDown(){
		grid[getHeroCol()][getHeroRow()-1].setContainsEnemy(false);
	}
	
	void AttackRight(){
		grid[getHeroCol()+1][getHeroRow()].setContainsEnemy(false);
	}

	public void setHeroCol(int heroCol) {
		this.heroCol = heroCol;
	}

	public int getHeroCol() {
		return heroCol;
	}

	public void setHeroRow(int heroRow) {
		this.heroRow = heroRow;
	}

	public int getHeroRow() {
		return heroRow;
	}

	public void setObjectiveCol(int objectiveCol) {
		this.objectiveCol = objectiveCol;
	}

	public int getObjectiveCol() {
		return objectiveCol;
	}

	public void setObjectiveRow(int objectiveRow) {
		this.objectiveRow = objectiveRow;
	}

	public int getObjectiveRow() {
		return objectiveRow;
	}
	
}

