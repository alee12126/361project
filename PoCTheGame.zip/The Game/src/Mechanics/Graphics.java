package Mechanics;

//import static Mechanics.Graphics.LoadTexture;
import static org.lwjgl.opengl.GL11.*;

//import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import org.lwjgl.LWJGLException;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.DisplayMode;
import org.newdawn.slick.opengl.Texture;
import org.newdawn.slick.opengl.TextureLoader;
import org.newdawn.slick.util.ResourceLoader;


public class Graphics {
	
	public static final int W = 450, H = 400;
	
	//draws the board for the frame
	public static void drawBoard(){
		Display.setTitle("Proof Of Concept: The Game");
		try {
			Display.setDisplayMode(new DisplayMode(W, H));
			Display.create();
		} catch (LWJGLException e) { 
			e.printStackTrace();
		}
		
		//Graphics for rendering the board
		glMatrixMode(GL_PROJECTION);	//Recognize board
		glLoadIdentity();				//Load Display
		glOrtho(0, W, H, 0, 1, -1);			//Sets up camera for screen to see in parameters(far left, far right, top, bottom, 3d(zNear), 3d(zFar))
		glMatrixMode(GL_MODELVIEW);		//Sets the screen view
		glEnable(GL_TEXTURE_2D);		//Enables us to draw textures to the screen
		glEnable(GL_BLEND);				//Allow to blend with the background so you can have transparency ones
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	}
	
//	public static void drawGrid(float x, float y, float width, float height){
//		glBegin(GL_QUADS);
//		glVertex2f(x, y);				//Top left corner
//		glVertex2f(x + width, y);		//Top right corner
//		glVertex2f(x + width, y + height);		//Bottom right corner
//		glVertex2f(x, y + height);		//Bottom left corner
//		glEnd();
//	}
	
	public static void drawColors(Texture t, float x, float y, float width, float height){
		t.bind();					//all the commands we run we'll be running until we run a new one
		glTranslatef(x,y,0);			//takes (x,y,z) and takes a paint image and populates the grid
		
		//Translates the global grid to local grid coordinates
		glBegin(GL_QUADS);
		glTexCoord2f(0,0);
		glVertex2f(0,0);
		glTexCoord2f(1,0);
		glVertex2f(width, 0);
		glTexCoord2f(1,1);
		glVertex2f(width, height);
		glTexCoord2f(0,1);
		glVertex2f(0,height);
		glEnd();
		glLoadIdentity();
		
	}
	
	public static Texture loadTexture(String toFile, String fileType){
		Texture tex = null;
		InputStream it = ResourceLoader.getResourceAsStream(toFile);
		try {
			tex = TextureLoader.getTexture(fileType, it);
		} catch (IOException e) {
			e.printStackTrace();
			Display.destroy();
			System.exit(1);
		}
	
		return tex;
	}
	
	public static Texture loadColors(String name){
		Texture tex = null;
		tex = loadTexture("Backgrounds/"+name+".png", "PNG");
		return tex;
	}
	
	
}
