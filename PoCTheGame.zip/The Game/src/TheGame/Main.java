package TheGame;


//import org.lwjgl.LWJGLException;
//import java.awt.event.ActionEvent;
//import java.awt.event.ActionListener;
//import java.awt.event.KeyEvent;
//import java.awt.event.KeyListener;
//import java.sql.Time;
//import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
//import javax.swing.Timer;

import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.*;

//import Mechanics.Enemy;
//import static org.lwjgl.opengl.GL11.*;
import static Mechanics.Graphics.*;
//import static Movement.Enemy;


public class Main{
	
	public static final int WIDTH = 450, HEIGHT = 400;
	Player p;
	Enemy e;
	private int w = 0;
	private int h = 0;
	
	
	public Main(){
		
		drawBoard();
		
		//Add your own tiles
		
		//Hard-Code of what board will look like
		int[][] board = {
				{1, 3, 0, 3, 0, 0, 3, 1, 0,},
				{1, 1, 0, 1, 0, 1, 1, 1, 3,},
				{2, 1, 0, 1, 0, 0, 0, 0, 0,},
				{3, 1, 0, 1, 0, 1, 1, 1, 0,},
				{0, 0, 0, 1, 0, 0, 0, 1, 0,},
				{0, 1, 1, 1, 1, 0, 0, 1, 0,},
				{0, 0, 0, 1, 0, 0, 0, 1, 0,},
				{1, 1, 0, 3, 0, 0, 1, 1, 4,},
		};
		
		//Sets new background for grid
		TileGrid boardCoord = new TileGrid(board);
		
//		e = new Enemy(loadColors("enemy"), boardCoord.getTile(8, 1), 50, 50, 1);
//		p = new Player(loadColors("hero"), boardCoord.getTile(8, 7), 50, 50, 1);
//		boardCoord.setTile(8, 1, TileType.Enemy);			
//		boardCoord.setTile(6, 0, TileType.Enemy);
//		boardCoord.setTile(1, 0, TileType.Enemy);
//		boardCoord.setTile(3, 7, TileType.Enemy);
//		boardCoord.setTile(3, 0, TileType.Enemy);
//		boardCoord.setTile(8, 7, TileType.Hero);		//Hero tile
		boardCoord.setTile(0, 2, TileType.Goal);
		
		
//		int enemySize = 5;
//		
//		for(int i = 0; i < enemySize; i++){
//			enemies.add(new Enemy(loadColors("enemy"), boardCoord.getTile(8, 1), 50, 50, 1));
//		}
		
//		boardBackground.setTile(8,7,boardBackground.getTile(5, 0).getType());	//Accents the tile next to the setTile
//		Enemy e = new Enemy(loadColors("board"), boardBackground.getTile(8, 7), 50, 50);	//Sets new enemy parameters
		
		
		for(int i=0; i<board.length; i++){
			for(int j=0; j<board[0].length; j++){
				if(board[i][j] == 4){
					w=i;
					h=j;
				}
			}
		}
		
		System.out.println(w+" "+h);
		
		JFrame openFrame = new JFrame ("Proof of Concept: The Game");
		openFrame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
		JOptionPane.showMessageDialog(openFrame, "Welcome to Proof of Concept: The Game. Press OK to play.");
		
		while(!Display.isCloseRequested()){

			boardCoord.draw();
			
			while(Keyboard.next()){
				if(Keyboard.getEventKeyState()){
					if(Keyboard.getEventKey() == Keyboard.KEY_W){
						System.out.println(w+" "+h);
						//try{
						//	if((board[w][h-1] == 0) || (board[w][h-1] ==2)){
								board[w][h] = 0;
								w--;
								board[w][h] = 4;
								boardCoord = new TileGrid(board);
								boardCoord.draw();
							//}
						//}catch(ArrayIndexOutOfBoundsException e){}
					}
					if(Keyboard.getEventKey() == Keyboard.KEY_A){
					//	try{
						//	if((board[w-1][h] == 0) || (board[w-1][h] ==2)){
								board[w][h] = 0;
								h--;
								board[w][h] = 4;
								boardCoord = new TileGrid(board);
								boardCoord.draw();
							//}
						//}catch(ArrayIndexOutOfBoundsException e){}
					}
					if(Keyboard.getEventKey() == Keyboard.KEY_S){
						//try{
						//	if((board[w][h+1] == 0) || (board[w][h+1] ==2)){
								board[w][h] = 0;
								w++;
								board[w][h] = 4;
								boardCoord = new TileGrid(board);
								boardCoord.draw();
							//}
						//}catch(ArrayIndexOutOfBoundsException e){}
					}
					if(Keyboard.getEventKey() == Keyboard.KEY_D){
						//try{
							//if((board[w+1][h] == 0) || (board[w+1][h] ==2)){
								board[w][h] = 0;
								h++;
								board[w][h] = 4;
								boardCoord = new TileGrid(board);
								boardCoord.draw();
					}
					
					if(w==2 && h==0){
						
						JFrame winFrame = new JFrame ("Proof of Concept: The Game");
						winFrame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
						JOptionPane.showMessageDialog(winFrame, "You Won! Good job. You must be REALLY proud of yourself, overcoming such a difficult challenge." +
								"Maybe you should take a break so you don't faint due to mental exaustion.");
						
						System.exit(0);
					}
				}
			}
			
			
//			e.draw();
//			p.draw();
			
			
			
			//Sets the screen to update in the loop to render the black screen and fps (frame per second)
			Display.update();
			Display.sync(60);
		}
		
		
		
		//Ends the Game
		Display.destroy();
		
	}
	
	public static void main(String [] args){
		new Main();
	}

//	@Override
//	public void actionPerformed(ActionEvent arg0){
//		p.update();
//		
//	}
	
//	public void addEnemy(TheGame.Enemy el) {
//		enemies.add(e);
//		
//	}
//	
//	public static ArrayList<TheGame.Enemy> getEnemyList() {
//		return enemies;
//	}
//	
//	public static void removeEnemy(TheGame.Enemy e) {
//		enemies.remove(e);
//	}
	
//	public void addEnemy(TheGame.Enemy e) {
//		enemies.add(e);
//		
//	}
//	
//	public static ArrayList<TheGame.Enemy> getEnemyList() {
//		return enemies;
//	}
//	
//	public static void removeEnemy(TheGame.Enemy e) {
//		enemies.remove(e);
//	}
}
