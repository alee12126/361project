package TheGame;

public class TileGrid {
	
	public Tile[][] board;
	
	public Tile[][] getBoard() {
		return board;
	}

	

	public TileGrid(){
		board = new Tile[9][8];
		for(int i = 0; i < board.length; i++){
			for(int j = 0; j < board[i].length; j++){
				board[i][j] = new Tile(i * 50, j * 50, 50, 50, TileType.Background);
			}
		}
	}
	
	public TileGrid(int[][] grid){
		board = new Tile[9][8];
		for(int i = 0; i < board.length; i++){
			for(int j = 0; j < board[i].length; j++){
				switch(grid[j][i]){
					case 0: 
						board[i][j] = new Tile(i * 50, j * 50, 50, 50, TileType.Background);
						break;
					case 1:
						board[i][j] = new Tile(i * 50, j * 50, 50, 50, TileType.Walls);
						break;
					case 2: 
						board[i][j] = new Tile(i * 50, j * 50, 50, 50, TileType.Goal);
						break;
					case 3:
						board[i][j] = new Tile(i * 50, j * 50, 50, 50, TileType.Enemy);
						break;
					case 4: 
						board[i][j] = new Tile(i * 50, j * 50, 50, 50, TileType.Hero);
						break;
						
				}
			}
		}
	}
	
	public void setTile(int xCoord, int yCoord, TileType type){
		board[xCoord][yCoord] = new Tile(xCoord * 50, yCoord * 50, 50, 50, type);
	}
	
	public Tile getTile(int xCoord, int yCoord){
		return board[xCoord][yCoord];
	}
	
	public void draw(){
		for(int i = 0; i < board.length; i++){
			for(int j = 0; j < board[i].length; j++){
				board[i][j].draw();
			}
		}
	}
}
