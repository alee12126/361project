package TheGame;

public enum TileType {

	Background("grass", true), Walls("rsz_blue", false), 
	Goal("money", true), Enemy("enemy", false), Hero("hero", false);
	
	String texName;
	boolean canUBuild;
	
	TileType(String texName, boolean canUBuild){
		this.texName = texName;
		this.canUBuild = canUBuild;
	}
}
