package TheGame;

//import java.awt.Rectangle;
import java.awt.geom.Rectangle2D;

import org.newdawn.slick.opengl.Texture;

import static Mechanics.Graphics.*;

public class Enemy {
	
	private float x,y, speed;
	private int width,height;
//	private health;
	Texture texture;
	private Tile startTile;
	
	public Enemy(Texture texture, Tile startTile, int width, int height, float speed){
		this.texture = texture;
		this.x = startTile.getX();
		this.y = startTile.getY();
		this.width = width;
		this.height = height;
		this.speed = speed;
		
	}
	
	public void draw() {
		drawColors(texture, x, y, width, height);
	}
	
	public Rectangle2D getBounds() {	
		return new Rectangle2D.Float(x, y, texture.getWidth(), texture.getHeight());
	}
}
