package TheGame;

//import java.awt.Image;
//import java.awt.Rectangle;
//import java.awt.event.KeyEvent;
//import java.awt.event.KeyListener;
import java.awt.geom.Rectangle2D;
//import java.util.ArrayList;
//
//import Mechanics.*;
//import Backgrounds.*;
//import TheGame.*;
//
//import javax.swing.ImageIcon;

import org.newdawn.slick.opengl.Texture;

//import java.awt.Rectangle;
//import java.awt.geom.Rectangle2D;
//
//import org.newdawn.slick.opengl.Texture;

import static Mechanics.Graphics.*;


public class Player{

	private float velX = 0, velY = 0;
	private float x,y, speed;
	private int width,height;
//	private health;
	Texture texture;
	private Tile startTile;
	
	public Player(Texture texture, Tile startTile, int width, int height, float speed){
		this.texture = texture;
		this.x = startTile.getX();
		this.y = startTile.getY();
		this.width = width;
		this.height = height;
		this.speed = speed;
		
	}
	
	public void update(){
		y += velY;
		x += velX;
		
//		checkCollisions();
	}
	
	public void draw(){
		drawColors(texture, x, y, width, height);
	}

//	public void keyPressed(KeyEvent e) {
//		int key = e.getKeyCode();
//		
//		if(key == KeyEvent.VK_W){
//			velY = -speed;
//		} else if(key == KeyEvent.VK_S){
//			velY = speed;
//		} else if(key == KeyEvent.VK_A){
//			velX = -speed;
//		} else if(key == KeyEvent.VK_D){
//			velX = speed;
//		}
//	}
//	
//	public void keyReleased(KeyEvent e) {
//		int key = e.getKeyCode();
//		
//		if(key == KeyEvent.VK_W){
//			velY = 0;
//		} else if(key == KeyEvent.VK_S){
//			velY = 0;
//		} else if(key == KeyEvent.VK_A){
//			velX = 0;
//		} else if(key == KeyEvent.VK_D){
//			velX = 0;
//		}
//	}
//	
	
	public Rectangle2D getBounds() {
		return new Rectangle2D.Float(x, y, texture.getWidth(), texture.getHeight());
	}

	
	
}
